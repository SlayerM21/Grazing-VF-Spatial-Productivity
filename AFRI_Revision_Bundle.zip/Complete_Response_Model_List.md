# AFRI variables, models, and datasets — restored original methods

The manuscript workflow restores the methods in the supplied original Rmd. There are 44 canonical reporting specifications and 12 exploratory/source catalog entries. Source entries do not replace canonical manuscript fits. Original research datasets are absent here; actual study estimates and a full knit have not been verified.

Season models use `TRT * SR` and random Year and physical Pasture intercepts where estimable. Period models use `TRT * SR * Period`, including all interactions. The original period engine compares RI and AR(1) candidates; an eligible converged AR(1) is retained when it improves AIC by at least 2, or the RI fit is invalid. Animal-period models use the original within-year animal clustering. Pasture_Year indexes the annual AR(1) sequence, not an additional pasture-year random intercept.

Original family rules are restored: Gaussian/identity for prespecified Gaussian outcomes; Gamma/log for positive area and gas ratios; zero responses use Tweedie/log and negative responses use Gaussian under the original rules. `auto_positive` compares Gaussian with Gamma or Tweedie by AIC. Original numerical fallback rules are retained, and the final fitted family/formula is reported rather than assumed.

Table 1 uses the original quality-controlled animal-year behavior and movement summaries. The final workbook keeps Table_1_Grazing_Behaviors first, routes season animal responses to Table2 and land responses to WholeSeason_Additional, and retains Pasture_RGP and Animal_RGP. Outside-RGP active-area and combined-gas responses remain removed. Existing files from older runs are not deleted. Run a fresh R session and rerun all data and model chunks.

| Entry | Response | Scale / unit | Family rule | RI formula / source formula | Input dataset | Role |
|---|---|---|---|---|---|---|
| 1 | `Grazing_h` | season / animal | gaussian | `Grazing_h ~ TRT * SR + (1 \| Year) + (1 \| Pasture)` | `Table1_Grazing_Behaviors` | Canonical manuscript model |
| 2 | `Resting_h` | season / animal | gaussian | `Resting_h ~ TRT * SR + (1 \| Year) + (1 \| Pasture)` | `Table1_Grazing_Behaviors` | Canonical manuscript model |
| 3 | `Traveling_h` | season / animal | auto_positive | `Traveling_h ~ TRT * SR + (1 \| Year) + (1 \| Pasture)` | `Table1_Grazing_Behaviors` | Canonical manuscript model |
| 4 | `mean_DDT_day` | season / animal | auto_positive | `mean_DDT_day ~ TRT * SR + (1 \| Year) + (1 \| Pasture)` | `Table1_Grazing_Behaviors` | Canonical manuscript model |
| 5 | `CH4_Mean_g_d` | season / animal | auto_positive | `CH4_Mean_g_d ~ TRT * SR + (1 \| Year) + (1 \| Pasture)` | `dressler_animal_means` | Canonical manuscript model |
| 6 | `CO2_Mean_g_d` | season / animal | auto_positive | `CO2_Mean_g_d ~ TRT * SR + (1 \| Year) + (1 \| Pasture)` | `dressler_animal_means` | Canonical manuscript model |
| 7 | `Smooth_Period_ADG` | season / animal | gaussian | `Smooth_Period_ADG ~ TRT * SR + (1 \| Year) + (1 \| Pasture)` | `animal_spline_metrics` | Canonical manuscript model |
| 8 | `Shrunk_Initial_BW_kg` | season / animal | gaussian | `Shrunk_Initial_BW_kg ~ TRT * SR + (1 \| Year) + (1 \| Pasture)` | `shrunk_bw_season_analysis` | Canonical manuscript model |
| 9 | `Shrunk_Final_BW_kg` | season / animal | gaussian | `Shrunk_Final_BW_kg ~ TRT * SR + (1 \| Year) + (1 \| Pasture)` | `shrunk_bw_season_analysis` | Canonical manuscript model |
| 10 | `CH4_g_per_active_ha_whole_season` | season / pasture | auto_positive | `CH4_g_per_active_ha_whole_season ~ TRT * SR + (1 \| Year) + (1 \| Pasture)` | `whole_season_grazing_productivity` | Canonical manuscript model |
| 11 | `CO2_g_per_active_ha_whole_season` | season / pasture | auto_positive | `CO2_g_per_active_ha_whole_season ~ TRT * SR + (1 \| Year) + (1 \| Pasture)` | `whole_season_grazing_productivity` | Canonical manuscript model |
| 12 | `active_ha_whole_season` | season / pasture | auto_positive | `active_ha_whole_season ~ TRT * SR + (1 \| Year) + (1 \| Pasture)` | `whole_season_grazing_productivity` | Canonical manuscript model |
| 13 | `LWG_kg_per_active_ha_whole_season` | season / pasture | auto_positive | `LWG_kg_per_active_ha_whole_season ~ TRT * SR + (1 \| Year) + (1 \| Pasture)` | `whole_season_grazing_productivity` | Canonical manuscript model |
| 14 | `active_ha_all_pasture` | period / pasture | gamma_log | `active_ha_all_pasture ~ TRT * SR * Period + (1 \| Year) + (1 \| Pasture)` | `period_level_grazing_productivity` | Canonical manuscript model |
| 15 | `active_ha_inside_rgp` | period / pasture | gamma_log | `active_ha_inside_rgp ~ TRT * SR * Period + (1 \| Year) + (1 \| Pasture)` | `period_level_grazing_productivity` | Canonical manuscript model |
| 16 | `total_LWG_kg` | season / pasture | gaussian | `total_LWG_kg ~ TRT * SR + (1 \| Year) + (1 \| Pasture)` | `whole_season_grazing_productivity` | Canonical manuscript model |
| 17 | `mean_RGP_ADG_kg_day` | period / pasture | gaussian | `mean_RGP_ADG_kg_day ~ TRT * SR * Period + (1 \| Year) + (1 \| Pasture)` | `period_level_grazing_productivity` | Canonical manuscript model |
| 18 | `CH4_g_animal_day` | period / pasture | gaussian | `CH4_g_animal_day ~ TRT * SR * Period + (1 \| Year) + (1 \| Pasture)` | `period_level_grazing_productivity` | Canonical manuscript model |
| 19 | `CO2_g_animal_day` | period / pasture | gaussian | `CO2_g_animal_day ~ TRT * SR * Period + (1 \| Year) + (1 \| Pasture)` | `period_level_grazing_productivity` | Canonical manuscript model |
| 20 | `LWG_kg_per_active_ha_all_pasture` | period / pasture | gaussian | `LWG_kg_per_active_ha_all_pasture ~ TRT * SR * Period + (1 \| Year) + (1 \| Pasture)` | `period_level_grazing_productivity` | Canonical manuscript model |
| 21 | `LWG_kg_per_active_ha_inside_rgp` | period / pasture | gaussian | `LWG_kg_per_active_ha_inside_rgp ~ TRT * SR * Period + (1 \| Year) + (1 \| Pasture)` | `period_level_grazing_productivity` | Canonical manuscript model |
| 22 | `CH4_g_per_active_ha_all_pasture` | period / pasture | gamma_log | `CH4_g_per_active_ha_all_pasture ~ TRT * SR * Period + (1 \| Year) + (1 \| Pasture)` | `period_level_grazing_productivity` | Canonical manuscript model |
| 23 | `CH4_g_per_active_ha_inside_rgp` | period / pasture | gamma_log | `CH4_g_per_active_ha_inside_rgp ~ TRT * SR * Period + (1 \| Year) + (1 \| Pasture)` | `period_level_grazing_productivity` | Canonical manuscript model |
| 24 | `CO2_g_per_active_ha_all_pasture` | period / pasture | gamma_log | `CO2_g_per_active_ha_all_pasture ~ TRT * SR * Period + (1 \| Year) + (1 \| Pasture)` | `period_level_grazing_productivity` | Canonical manuscript model |
| 25 | `CO2_g_per_active_ha_inside_rgp` | period / pasture | gamma_log | `CO2_g_per_active_ha_inside_rgp ~ TRT * SR * Period + (1 \| Year) + (1 \| Pasture)` | `period_level_grazing_productivity` | Canonical manuscript model |
| 26 | `CH4_g_per_kg_LWG` | period / pasture | gamma_log | `CH4_g_per_kg_LWG ~ TRT * SR * Period + (1 \| Year) + (1 \| Pasture)` | `period_level_grazing_productivity` | Canonical manuscript model |
| 27 | `CO2_g_per_kg_LWG` | period / pasture | gamma_log | `CO2_g_per_kg_LWG ~ TRT * SR * Period + (1 \| Year) + (1 \| Pasture)` | `period_level_grazing_productivity` | Canonical manuscript model |
| 28 | `total_LWG_kg` | season / pasture | gaussian | `total_LWG_kg ~ TRT * SR + (1 \| Year) + (1 \| Pasture)` | `whole_season_grazing_productivity` | Canonical manuscript model |
| 29 | `mean_Shrunk_Initial_BW_kg` | season / pasture | gaussian | `mean_Shrunk_Initial_BW_kg ~ TRT * SR + (1 \| Year) + (1 \| Pasture)` | `whole_season_grazing_productivity` | Canonical manuscript model |
| 30 | `mean_Shrunk_Final_BW_kg` | season / pasture | gaussian | `mean_Shrunk_Final_BW_kg ~ TRT * SR + (1 \| Year) + (1 \| Pasture)` | `whole_season_grazing_productivity` | Canonical manuscript model |
| 31 | `mean_Whole_Season_Smooth_ADG_kg_day` | season / pasture | gaussian | `mean_Whole_Season_Smooth_ADG_kg_day ~ TRT * SR + (1 \| Year) + (1 \| Pasture)` | `whole_season_grazing_productivity` | Canonical manuscript model |
| 32 | `whole_season_animal_avg_CH4_g_day` | season / pasture | gaussian | `whole_season_animal_avg_CH4_g_day ~ TRT * SR + (1 \| Year) + (1 \| Pasture)` | `whole_season_grazing_productivity` | Canonical manuscript model |
| 33 | `whole_season_animal_avg_CO2_g_day` | season / pasture | gaussian | `whole_season_animal_avg_CO2_g_day ~ TRT * SR + (1 \| Year) + (1 \| Pasture)` | `whole_season_grazing_productivity` | Canonical manuscript model |
| 34 | `CH4_g_per_active_ha_day_whole_season` | season / pasture | auto_positive | `CH4_g_per_active_ha_day_whole_season ~ TRT * SR + (1 \| Year) + (1 \| Pasture)` | `whole_season_grazing_productivity` | Canonical manuscript model |
| 35 | `CO2_g_per_active_ha_day_whole_season` | season / pasture | auto_positive | `CO2_g_per_active_ha_day_whole_season ~ TRT * SR + (1 \| Year) + (1 \| Pasture)` | `whole_season_grazing_productivity` | Canonical manuscript model |
| 36 | `ADG_Land_kg_per_active_ha_day_whole_season` | season / pasture | gaussian | `ADG_Land_kg_per_active_ha_day_whole_season ~ TRT * SR + (1 \| Year) + (1 \| Pasture)` | `whole_season_grazing_productivity` | Canonical manuscript model |
| 37 | `CH4_g_per_kg_LWG_whole_season` | season / pasture | gamma_log | `CH4_g_per_kg_LWG_whole_season ~ TRT * SR + (1 \| Year) + (1 \| Pasture)` | `whole_season_grazing_productivity` | Canonical manuscript model |
| 38 | `CO2_g_per_kg_LWG_whole_season` | season / pasture | gamma_log | `CO2_g_per_kg_LWG_whole_season ~ TRT * SR + (1 \| Year) + (1 \| Pasture)` | `whole_season_grazing_productivity` | Canonical manuscript model |
| 39 | `Whole_Season_CH4_g_day` | season / animal | gaussian | `Whole_Season_CH4_g_day ~ TRT * SR + (1 \| Year) + (1 \| Pasture)` | `shrunk_bw_season_analysis` | Canonical manuscript model |
| 40 | `Whole_Season_CO2_g_day` | season / animal | gaussian | `Whole_Season_CO2_g_day ~ TRT * SR + (1 \| Year) + (1 \| Pasture)` | `shrunk_bw_season_analysis` | Canonical manuscript model |
| 41 | `Whole_Season_Smooth_ADG_kg_day` | season / animal | gaussian | `Whole_Season_Smooth_ADG_kg_day ~ TRT * SR + (1 \| Year) + (1 \| Pasture)` | `shrunk_bw_season_analysis` | Canonical manuscript model |
| 42 | `RGP_CH4_g_day` | period / animal | gaussian | `RGP_CH4_g_day ~ TRT * SR * Period + (1 \| Year) + (1 \| Pasture) + (1 \| Animal_Year_ID)` | `shrunk_bw_period_analysis` | Canonical manuscript model |
| 43 | `RGP_CO2_g_day` | period / animal | gaussian | `RGP_CO2_g_day ~ TRT * SR * Period + (1 \| Year) + (1 \| Pasture) + (1 \| Animal_Year_ID)` | `shrunk_bw_period_analysis` | Canonical manuscript model |
| 44 | `RGP_Smooth_ADG_kg_day` | period / animal | gaussian | `RGP_Smooth_ADG_kg_day ~ TRT * SR * Period + (1 \| Year) + (1 \| Pasture) + (1 \| Animal_Year_ID)` | `shrunk_bw_period_analysis` | Canonical manuscript model |
| 45 | `CH4_g_d` | period / pasture | Exploratory source; see source chunk | `CH4_g_d ~ TRT * SR * RotationPeriod + (1 \| Year) + (1 \| Pasture)` | `ch4_rotation_model_data` | Exploratory/source only |
| 46 | `CO2_g_d` | period / pasture | Exploratory source; see source chunk | `CO2_g_d ~ TRT * SR * RotationPeriod + (1 \| Year) + (1 \| Pasture)` | `co2_rotation_model_data` | Exploratory/source only |
| 47 | `Seasonal_ADG` | season / animal | Exploratory source; see source chunk | `Seasonal_ADG ~ TRT * SR + (1 \| Year) + (1 \| Pasture_ID)` | `bw_season_model_data` | Exploratory/source only |
| 48 | `FBW` | season / animal | Exploratory source; see source chunk | `FBW ~ IBW + TRT * SR + (1 \| Year) + (1 \| Pasture_ID)` | `bw_season_model_data` | Exploratory/source only |
| 49 | `CH4_g_d` | period / animal | Exploratory source; see source chunk | `CH4_g_d ~ TRT * SR * Period + (1 \| Year) + (1 \| Pasture)` | `gf_model_data (from gf_period_qualified)` | Exploratory/source only |
| 50 | `CO2_g_d` | period / animal | Exploratory source; see source chunk | `CO2_g_d ~ TRT * SR * Period + (1 \| Year) + (1 \| Pasture)` | `gf_model_data (from gf_period_qualified)` | Exploratory/source only |
| 51 | `Percent_pasture_active` | period / pasture | Exploratory source; see source chunk | `Percent_pasture_active ~ TRT * SR * RGP + (1 \| Pasture_ID) + (1 \| Year)` | `rgp_map_scopes [Grid_Map = ALL_PASTURE_GRAZING]` | Exploratory/source only |
| 52 | `Gain_kg_per_active_ha` | period / pasture | Exploratory source; see source chunk | `Gain_kg_per_active_ha ~ TRT * SR * RGP + (1 \| Pasture_ID) + (1 \| Year)` | `rgp_map_scopes [Grid_Map = ALL_PASTURE_GRAZING]` | Exploratory/source only |
| 53 | `Percent_pasture_active` | period / pasture | Exploratory source; see source chunk | `Percent_pasture_active ~ TRT * SR * RGP + (1 \| Pasture_ID) + (1 \| Year)` | `rgp_map_scopes [Grid_Map = INSIDE_RGP_GRAZING]` | Exploratory/source only |
| 54 | `Gain_kg_per_active_ha` | period / pasture | Exploratory source; see source chunk | `Gain_kg_per_active_ha ~ TRT * SR * RGP + (1 \| Pasture_ID) + (1 \| Year)` | `rgp_map_scopes [Grid_Map = INSIDE_RGP_GRAZING]` | Exploratory/source only |
| 55 | `Percent_pasture_active` | season / pasture | Exploratory source; see source chunk | `Percent_pasture_active ~ TRT * SR + (1 \| Pasture_ID) + (1 \| Year)` | `season_two_grid_outcomes [Grid_Map = WHOLE_SEASON_GRAZING]` | Exploratory/source only |
| 56 | `Gain_kg_per_active_ha` | season / pasture | Exploratory source; see source chunk | `Gain_kg_per_active_ha ~ TRT * SR + (1 \| Pasture_ID) + (1 \| Year)` | `season_two_grid_outcomes [Grid_Map = WHOLE_SEASON_GRAZING]` | Exploratory/source only |
